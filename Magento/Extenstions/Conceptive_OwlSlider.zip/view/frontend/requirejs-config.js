var config = {
    paths: {
        owlcarousel: "Conceptive_OwlSlider/js/owl.carousel"
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    }
};