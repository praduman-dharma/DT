This is Thecoachsmb Slider.

Unzip it in the App/code directory of your project.

Run below command to enable and work on :

php bin/magento module:enable Thecoachsmb_OwlSlider && php bin/magento setup:upgrade && php bin/magento setup:static-content:deploy -f

Then in the browser, hit the below url,
http://domain.com/owlslider/index/index

You will slider.
You can implement this in any extension which will fit your reuirement.

See extension details here - https://www.thecoachsmb.com/how-to-add-owl-carousel-slider-in-magento-2/
