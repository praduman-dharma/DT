# CHANGES #

### v1.0.1 ###
* Show downloads in product tab
* Chose wich filetype extensions are allowed from the admin settings

### v1.0.0 ###
* Adding a download to a product
* Overview of downloads from product edit page
* Show downloads on product page