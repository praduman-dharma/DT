### 1.0.4 ###
* making possible installing module when db tables' prefixes are used
* fix for attachment removal, when the only attachment is being deleted using product form
* fix for url-type attachment download

### 1.1.0 ###
* testing module on php 7.2 + support for php 7.2

### 1.2.0 ###
* tested module on php 7.3 + support for php 7.3 + tested on Magento 2.3.4

### 1.2.1 ###
* added dutch translation

### 1.2.2 ###
* fixed type error in attachment download controller

### 1.2.3 ###
* fixed conflict of file processing when downloadable product is going to have attachments
* added more verbosity to file uploader in adminhtml

### 1.3.0 ###
* major refactor of controllers
* fix for not working (because of different reasons) file downloads on frontend

### 1.3.1 ###
* fix for adminthtml routes.xml

### 1.3.2 ###
* fix for incorrect admin controller paths

### 1.3.3 ###
* enterprise magento version compatibility patch
* minor refactor
* compatibility fix for magento CE 2.3.5

### 1.3.4 ###
* fix for return type fix for configuration provider

### 1.3.5 ###
* do not show attachment tab on product page with no attachments

### 1.3.6 ###
* PHP 7.4 compatibility
* fix for windows issues in adminhtml
* changing visibility of helper function in block


### 1.3.7 ###
* fix constant attachment re-saving
* fix for stale downloaded files in magento root

### 1.3.8 ###
* fix for not saving attachment

### 1.3.9 ###
* compatibility with bundle and grouped product for Magento 2.3 and 2.4 

### 1.3.10 ###
* fix for title - attachment binding