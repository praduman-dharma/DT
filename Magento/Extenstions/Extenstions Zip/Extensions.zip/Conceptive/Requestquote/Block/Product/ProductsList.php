<?php
namespace Conceptive\Requestquote\Block\Product;
class ProductsList extends \Magento\CatalogWidget\Block\Product\ProductsList
{
}