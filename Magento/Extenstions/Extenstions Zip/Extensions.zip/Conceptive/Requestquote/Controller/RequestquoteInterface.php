<?php

namespace Conceptive\Requestquote\Controller;

use Magento\Framework\App\ActionInterface;

interface RequestquoteInterface extends ActionInterface
{
}
