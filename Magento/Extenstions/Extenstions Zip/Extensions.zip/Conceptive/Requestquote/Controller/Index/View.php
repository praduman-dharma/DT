<?php

namespace Conceptive\Requestquote\Controller\Index;

use Conceptive\Requestquote\Controller\RequestquoteInterface;

class View extends \Conceptive\Requestquote\Controller\AbstractController\View implements RequestquoteInterface
{

}
