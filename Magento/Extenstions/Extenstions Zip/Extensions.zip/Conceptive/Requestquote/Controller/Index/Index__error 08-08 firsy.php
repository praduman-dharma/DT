<?php

namespace Conceptive\Requestquote\Controller\Index;

use Magento\Framework\View\Result\PageFactory;
use Zend\Log\Filter\Timestamp;
use Magento\Store\Model\StoreManagerInterface;


class Index extends \Magento\Framework\App\Action\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    const XML_PATH_EMAIL_RECIPIENT_NAME = 'trans_email/ident_support/name';
    const XML_PATH_EMAIL_RECIPIENT_EMAIL = 'trans_email/ident_support/email';
     
    protected $_inlineTranslation;
    protected $_transportBuilder;
    protected $_scopeConfig;
    protected $_logLoggerInterface;
    protected $storeManager;
    
    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Psr\Log\LoggerInterface $loggerInterface,
        PageFactory $resultPageFactory,
        StoreManagerInterface $storeManager,
        array $data = []
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        $this->_scopeConfig = $scopeConfig;
        $this->_logLoggerInterface = $loggerInterface;
        $this->messageManager = $context->getMessageManager();
        $this->storeManager = $storeManager;
        parent::__construct($context);
    }
    
    /**
     * Default Requestquote Index page
     *
     * @return void
     */
    public function execute()
    {
        $this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->getPage()->getConfig()->getTitle()->set(__('Site Requestquote111'));
        // $post = (array) $this->getRequest()->getPost();
        $data = $this->getRequest()->getPost();
        $model = $this->_objectManager->create('Conceptive\Requestquote\Model\Requestquote');
     if($data){
        $query['name'] = $data['name'];          
        $query['email'] = $data['email'];         
        $query['phoneno'] = $data['phoneno'];       
        $query['comments'] = $data['comments']; 
        $query['product_id'] = $data['product_id']; 
        $query['product_name'] = $data['product_name'];           
            $model->setData($query);
            $model->Save();
        }
        $listBlock = $this->_view->getLayout()->getBlock('requestquote.list');

        if ($listBlock) {
            $currentPage = abs(intval($this->getRequest()->getParam('p')));
            if ($currentPage < 1) {
                $currentPage = 1;
            }
            
            $listBlock->setCurrentPage($currentPage);
        }
        
        /** @var \Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        return $resultPage;
    }
}
