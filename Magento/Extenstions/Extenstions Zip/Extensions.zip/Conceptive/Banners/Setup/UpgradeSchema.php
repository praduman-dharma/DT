<?php
namespace Conceptive\Banners\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Upgrade the Catalog module DB scheme
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function upgrade( SchemaSetupInterface $setup, ModuleContextInterface $context ) {
        $installer = $setup;

        $installer->startSetup();

        if(version_compare($context->getVersion(), '1.0.6', '<')) {
            $table = $installer->getConnection()->newTable(
            $installer->getTable('banner_summery')
        )->addColumn(
            'summery_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true,'comment'  => 'summery_id'],
            'summery_id'
        )->addColumn(
            'banner_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            255,
            ['nullable' => true,'comment'  => 'banner_id'],
            'Banner Id'
        )->addColumn(
            'link_click_count',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            ['nullable' => true,'default' => null,'comment'  => 'link_click_count'],
            'link_click_count'
        )->addColumn(
            'user_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '255',
            ['nullable' => true,'default' => null,'comment'  => 'user_name'],
            'User Name'
            
        )->addColumn(
            'email',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '255',
            ['nullable' => true,'default' => null,'comment'  => 'Email'],
            'Email'
        )->addColumn(
            'contact',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '255',
            ['nullable' => true,'default' => null,'comment'  => 'contact'],
            'contact'
        )->addColumn(
            'banner_click_time',
            \Magento\Framework\DB\Ddl\Table::TYPE_DATE,
            '255',
            ['nullable' => true,'default' => null,'comment'  => 'banner_click_time'],
            'banner_click_time'
           
        )->addColumn(
            'visitor_ip',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '100',
            ['nullable' => true,'default' => null,'comment'  => 'Visitor IP'],
            'visitor_ip'
        )->setComment(
            'Summery item'
        );
        $installer->getConnection()->createTable($table);
        }



        $installer->endSetup();
    }
}