<?php

namespace FME\Banners\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;

class Index extends \Magento\Framework\App\Action\Action
{

    /**
     * @var Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    protected $resultJsonFactory;

    protected $_resource;

    /**
     * @param Context     $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Magento\Framework\App\ResourceConnection $resource,
        PageFactory $resultPageFactory,
        JsonFactory $resultJsonFactory
    ) {

        $this->resultPageFactory = $resultPageFactory;
        $this->_resource = $resource;
        $this->resultJsonFactory = $resultJsonFactory;
        return parent::__construct($context);
    }


    public function execute()
    {
        $bannerId = $this->getRequest()->getParam('bannerId');
        echo "Banner Id : " . $bannerId . "<br>";


        $firstname = "Guest";
        $lastname = "Guest";
        $fullname = "Guest";
        $email = " ";
        $groupId = " ";

        // // get connection
        // $connection     = $this->_resource->getConnection();
        // // table name
        // $tableName = $this->_resource->getTableName('banner_summery');
        // // Query
        // $select_sql = "Select * FROM " . $tableName;
        // // fetch result
        // $results = $connection->fetchAll($select_sql);
        // // print result
        // print_r($results);

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\Session');
        if ($customerSession->isLoggedIn()) {
            $fullname = $customerSession->getCustomer()->getName();  // get  Full Name
            $email =  $customerSession->getCustomer()->getEmail(); // get Email
        }
        $click_count = 1;
        $contact = "99999999";

        $connection = $this->_resource->getConnection();

        $themeTable = $this->_resource->getTableName('banner_summery');

        $select_sql = "Select * FROM " . $themeTable;
        // fetch result
        $results = $connection->fetchAll($select_sql);
        // print result
        // print_r($results);
        $bannerIdArray = array();
        $nameArray = array();
        $emailArray = array();
        foreach ($results as $values) {
            foreach ($values as $key => $value) {
                if ($value == "Guest") {
                    continue;
                }
                if ($key == "banner_id") {
                    $bannerIdArray[] = $value;
                }
                if ($key == "user_name") {
                    $nameArray[] = $value;
                }
                if ($key == "email") {
                    $emailArray[] = $value;
                }
            }
        }

        print_r($bannerIdArray);

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $objDate = $objectManager->create('Magento\Framework\Stdlib\DateTime\DateTime');
        $date = $objDate->gmtDate();

        if (!(in_array($email, $emailArray) && in_array($fullname, $nameArray) && in_array($bannerId, $bannerIdArray)) || ($fullname == "Guest")) {
            $sql = "INSERT INTO " . $themeTable . "(banner_id, link_click_count, user_name, email, contact, banner_click_time) VALUES ('$bannerId', '$click_count','$fullname','$email','$contact','$date')";
            // $connection->query($sql); 
            echo "Inseting";
            if ($connection->query($sql)) {
                echo "Data Inserted Successfully";
            } else {
                echo "Data Not Inserted";
            }
            echo "Match not found";
        } else {
            echo "Match found";
        }
        return;
    }
}
