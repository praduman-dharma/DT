<?php

namespace FME\Banners\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;

class Index extends \Magento\Framework\App\Action\Action
{

    /**
     * @var Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    protected $resultJsonFactory;

    /**
     * @param Context     $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        JsonFactory $resultJsonFactory
    ) {

        $this->resultPageFactory = $resultPageFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        return parent::__construct($context);
    }


    public function execute()
    {
        $bannerId = $this->getRequest()->getParam('bannerId');
        echo "Banner Id : ". $bannerId . "<br>";

        $firstname = "Guest";
        $lastname = "Guest";
        $fullname = "Guest";
        $email = " ";
        $groupId = " ";

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\Session');
        if ($customerSession->isLoggedIn()) {
            $customerId = $customerSession->getCustomerId();  // get Customer Id
            $firstname =  $customerSession->getCustomer()->getFirstname() . "<br>";  // get  First Name
            $lastname =  $customerSession->getCustomer()->getLastname() . "<br>";  // get  Last Name
            $fullname = $customerSession->getCustomer()->getName() . "<br>";  // get  Full Name
            $email =  $customerSession->getCustomer()->getEmail(); // get Email
            $groupId =  $customerSession->getCustomer()->getGroupId(); // get Customer Group Id
        } else {
            $customerId = null;
        }
        echo "Customer ID : $customerId" ."<br>";
        echo "Customer firstname : $firstname" ."<br>";
        echo "Customer lastname : $lastname" ."<br>";
        echo "Customer fullname : $fullname" ."<br>";
        echo "Customer email : $email" ."<br>";
        echo "Customer groupId : $groupId" ."<br>";
        return;
        // $priceFrom = $this->getRequest()->getParam('pricefrom');
        // $priceTo = $this->getRequest()->getParam('priceto');
        // $result = $this->resultJsonFactory->create();
        // $resultPage = $this->resultPageFactory->create();


        // $block = $resultPage->getLayout()
        //         ->createBlock('Conceptive\AdvanceSearch\Block\ListProduct')
        //         ->setTemplate('Conceptive_AdvanceSearch::resultproduct.phtml')
        //         ->setData('listid',$numone)
        //         ->setData('attributeid',$attributeId)
        //         ->setData('pricefrom',$priceFrom)
        //         ->setData('priceto',$priceTo)
        //         ->toHtml();

        // $result->setData(['output' => $block]);
        // if (empty($numone) && empty($attributeId) && empty($priceFrom) && empty($priceTo)) {
        //     $resultRedirect = $this->resultRedirectFactory->create();
        //     $resultRedirect->setPath('checkout/cart/index');
        //     return $resultRedirect;
        // } else {
        //     return $result;
        // }
    }
}