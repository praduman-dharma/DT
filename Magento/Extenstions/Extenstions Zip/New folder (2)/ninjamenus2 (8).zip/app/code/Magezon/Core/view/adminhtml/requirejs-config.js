var config = {
    map: {
        "*": {
            "mgzmediabrowser": "Magezon_Core/js/mage/browser",
        }
    },
    shim: {
        'produclabels': {
            'deps': ['jquery']
        }
    }
};