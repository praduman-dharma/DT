<?php


namespace Avologic\Base\Model;

use Magento\Framework\Config\ConfigOptionsListConstants;

/**
 * Avologic Base admin notification feed model
 */
class AdminNotificationFeed extends \Magento\AdminNotification\Model\Feed
{
    /**
     * @var \Avologic\Base\Helper\Base
     */
    protected $baseHelper;

    /**
     * @var \Avologic\Base\Model\ProductFactory
     */
    protected $baseProductFactory;

    /**
     * @var \Magento\Backend\Model\Auth\Session
     */
    protected $_backendAuthSession;

    /**
     * @var Magento\Framework\Module\ModuleListInterface
     */
    protected $_moduleList;

    /**
     * @var \Magento\Framework\App\ProductMetadataInterface
     */
    protected $_productMetadata;

    /**
     * @var Magento\Framework\Module\Manager
     */
    protected $_moduleManager;

    /**
     * @param \Magento\Framework\Model\Context                        $context
     * @param \Magento\Framework\Registry                             $registry
     * @param \Magento\Backend\App\ConfigInterface                    $backendConfig
     * @param InboxFactory                                            $inboxFactory
     * @param \Avologic\Base\Helper\Base                            $baseHelper
     * @param \Avologic\Base\Model\ProductFactory $baseProductFactory
     * @param \Magento\Backend\Model\Auth\Session                     $backendAuthSession
     * @param \Magento\Framework\Module\ModuleListInterface           $moduleList
     * @param \Magento\Framework\Module\Manager                       $moduleManager,
     * @param \Magento\Framework\HTTP\Adapter\CurlFactory             $curlFactory
     * @param \Magento\Framework\App\DeploymentConfig                 $deploymentConfig
     * @param \Magento\Framework\App\ProductMetadataInterface         $productMetadata
     * @param \Magento\Framework\UrlInterface                         $urlBuilder
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb           $resourceCollection
     * @param array                                                   $data
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Backend\App\ConfigInterface $backendConfig,
        \Magento\AdminNotification\Model\InboxFactory $inboxFactory,
        \Avologic\Base\Helper\Base $baseHelper,
        \Avologic\Base\Model\ProductFactory $baseProductFactory,
        \Magento\Backend\Model\Auth\Session $backendAuthSession,
        \Magento\Framework\Module\ModuleListInterface $moduleList,
        \Magento\Framework\Module\Manager $moduleManager,
        \Magento\Framework\HTTP\Adapter\CurlFactory $curlFactory,
        \Magento\Framework\App\DeploymentConfig $deploymentConfig,
        \Magento\Framework\App\ProductMetadataInterface $productMetadata,
        \Magento\Framework\UrlInterface $urlBuilder,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct($context, $registry, $backendConfig, $inboxFactory, $curlFactory, $deploymentConfig, $productMetadata, $urlBuilder, $resource, $resourceCollection, $data);

        $this->baseHelper = $baseHelper;
        $this->baseProductFactory = $baseProductFactory;
        $this->_backendAuthSession  = $backendAuthSession;
        $this->_moduleList = $moduleList;
        $this->_moduleManager = $moduleManager;
        $this->_productMetadata = $productMetadata;
    }

    /**
     * Retrieve feed url
     *
     * @return string
     */
    public function getFeedUrl()
    {
        if ($this->_feedUrl === null) {
            $this->_feedUrl = 'https://st' . 'ore.avologic'
             . '.c' . 'om/notifica' . 'tionma' . 'nager/feed' . '/' . 'index/';
        }

        $urlInfo = parse_url($this->urlBuilder->getBaseUrl());
        $domain = isset($urlInfo['host']) ? $urlInfo['host'] : '';

        $url = $this->_feedUrl . 'domain/' . urlencode($domain);

        $modulesParams = [];
        foreach($this->getAllAvologicModules() as $key => $module) {
            $key = str_replace('Avologic_', '', $key);
            $modulesParams[] = $key . ',' . $module['setup_version'] . ',' . $this->getNotificationKey($key);
        }

        if (count($modulesParams)) {
            $url .= '/modules/' . base64_encode(implode(';', $modulesParams));
        }

        $ed = $this->_productMetadata->getEdition();
        $url .= '/platform/' . (($ed == 'Comm'.'unity') ? 'm2ce' : 'm2ee');
        $url .= '/edition/' . $ed;
        $url .= '/magento_version/' . $this->baseHelper->getMagento2Version();

        return $url;
    }

    /**
     * Get Avologic extewnsion info
     *
     * @return $this
     */
    protected function getAllAvologicModules()
    {
        $modules = [];
        foreach($this->_moduleList->getAll() as $moduleName => $module) {
            if (strpos($moduleName, 'Avologic_') !== false && $this->_moduleManager->isEnabled($moduleName) ) {
                $modules[$moduleName] = $module;
            }
        }
        return $modules;
    }

    /**
     * Check feed for modification
     *
     * @return $this
     */
    public function checkUpdate()
    {
        $session = $this->_backendAuthSession;
        $time = time();
        $frequency = $this->getFrequency();
        if (($frequency + $session->getMfBaseNoticeLastUpdate() > $time)
            || ($frequency + $this->getLastUpdate() > $time)
        ) {
            return $this;
        }

        $session->setPANLastUpdate($time);
        return parent::checkUpdate();
    }

    /**
     * Retrieve update frequency
     *
     * @return int
     */
    public function getFrequency()
    {
        return 86400;
    }

    /**
     * Retrieve last update time
     *
     * @return int
     */
    public function getLastUpdate()
    {
        return $this->_cacheManager->load('avologic_admin_notifications_lastcheck');
    }

    /**
     * Set last update time (now)
     *
     * @return $this
     */
    public function setLastUpdate()
    {
        $this->_cacheManager->save(time(), 'avologic_admin_notifications_lastcheck');
        return $this;
    }

    /**
     * Receive key
     *
     * @param string $name
     * @return null | string
     */
    public function getNotificationKey($name)
    {
        $product = $this->baseProductFactory->create()
            ->setName($name);

        if ($product) {
            return join(',', [
                $product->getCustomer(),
                $product->getSession()
            ]);
        }

        return null;
    }
}
