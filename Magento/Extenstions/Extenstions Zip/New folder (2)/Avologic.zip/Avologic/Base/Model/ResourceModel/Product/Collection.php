<?php


namespace Avologic\Base\Model\ResourceModel\Product;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init('Avologic\Base\Model\Product', 'Avologic\Base\Model\ResourceModel\Product');
    }
}
