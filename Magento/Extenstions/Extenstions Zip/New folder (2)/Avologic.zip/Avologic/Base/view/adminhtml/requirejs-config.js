var config = {
    map: {
        '*': {
            jscolor: 'Avologic_Base/js/jscolor'
        }
    }
};