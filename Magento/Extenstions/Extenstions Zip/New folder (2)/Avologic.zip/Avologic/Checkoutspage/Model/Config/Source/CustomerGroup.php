<?php


namespace Avologic\Checkoutspage\Model\Config\Source;

class CustomerGroup implements \Magento\Framework\Option\ArrayInterface
{

    /**
     * @var \Magento\Customer\Model\GroupFactory
     */
    protected $_customerGroupFactory;

    /**
     * @var \Magento\Customer\Model\Group
     */
    protected $_collection;

    /**
     * @param \Magento\Customer\Model\GroupFactory $groupFactory 
     */
    public function __construct(
        \Magento\Customer\Model\GroupFactory $groupFactory
    ) {
        $this->_customerGroupFactory = $groupFactory;
    }


    /**
     * get collection
     * @return \Magento\Customer\Model\Group
     */
    protected function _getCollection()
    {
        if ($this->_collection === null) {
            $this->_collection = $this->_customerGroupFactory->create()
                ->getCollection();
        }

        return $this->_collection;
    }

    /**
     * Options getter
     * @return array
     */
    public function toOptionArray()
    {
        $rules = [];
        foreach ($this->_getCollection() as $item) {
            $rules[] = [
                'value' =>  $item->getCustomerGroupId(), 'label' =>  $item->getCustomerGroupCode()
            ];
        }

        return $rules;
    }

    /**
     * Get options in "key-value" format
     * @return array
     */
    public function toArray()
    {
        $rules = [];

        foreach ($this->_getCollection() as $item) {
            $rules[$item->getCustomerGroupId()] = $item->getCustomerCode();
        }

        return $rules;
    }
}
