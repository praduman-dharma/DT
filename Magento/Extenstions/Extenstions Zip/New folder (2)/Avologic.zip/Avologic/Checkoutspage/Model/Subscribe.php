<?php


namespace Avologic\Checkoutspage\Model;

class Subscribe
{
    /**
     * @var \Avologic\Checkoutspage\Helper\Data 
     */
    protected $_dataHelper;

    /**
     * @var \Magento\Newsletter\Model\SubscriberFactory 
     */
    protected $_subscribeFactory;

    /**
     * @var array
     */
    protected $_errors = [];

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $_customerFactory;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeInterface;

    /**
     * @param \Avologic\Checkoutspage\Helper\Data       $dataHelper       
     * @param \Magento\Newsletter\Model\SubscriberFactory $subscribeFactory 
     * @param \Magento\Customer\Model\Customer            $customer         
     * @param \Magento\Store\Model\StoreManagerInterface  $storeInterface   
     */
    public function __construct(
        \Avologic\Checkoutspage\Helper\Data $dataHelper,
        \Magento\Newsletter\Model\SubscriberFactory $subscribeFactory,
        \Magento\Customer\Model\Customer $customer,
        \Magento\Store\Model\StoreManagerInterface $storeInterface
    ) {
        $this->_dataHelper = $dataHelper;
        $this->_subscribeFactory = $subscribeFactory;
        $this->_customerFactory = $customer;
        $this->_storeInterface = $storeInterface;
    }

    /**
     * Subscribe by current order
     * @param int $customerId 
     * @return boolean
     */
    public function subscribe($customerId = null)
    {
        $order = $this->_dataHelper->getOrder();
        try {
            $subscriber = $this->_subscribeFactory->create();
            if ($customerId === null) {
                $customer = $this->_customerFactory
                    ->setStore($this->_storeInterface->getStore())
                    ->loadByEmail($order->getCustomerEmail());
                if ($customer->getId()) {
                    $subscriber->subscribeCustomerById($customer->getId());
                } else {
                    $subscriber->setEmail($order->getCustomerEmail());
                }
            } else {
                $subscriber->subscribeCustomerById($customerId);
            }
            $subscriber->save();
        } catch (\Exeption $e) {
            $this->_errors[] = $e->getMessage();
        }

        return false;
    }

    /**
     * Get errors
     * @return Array 
     */
    public function getErrors()
    {
        return $this->_errors;
    }
}
