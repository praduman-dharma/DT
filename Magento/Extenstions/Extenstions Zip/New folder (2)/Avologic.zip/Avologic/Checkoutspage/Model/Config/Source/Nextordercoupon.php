<?php


namespace Avologic\Checkoutspage\Model\Config\Source;

class Nextordercoupon extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * @var \Magento\SalesRule\Model\ResourceModel\Rule\Collection
     */
    protected $_collection;

    /**
     * @var \Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory
     */
    protected $_ruleCollectionFactory;

    /**
     * @param \Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory $ruleCollectionFactory [description]
    */
    public function __construct(
        \Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory $ruleCollectionFactory
    ) {
        $this->_ruleCollectionFactory = $ruleCollectionFactory;
    }

    public function getAllOptions()
    {
        if ($this->_collection === null) {
            $coupons = $this->_ruleCollectionFactory
                ->create()
                ->addFieldToFilter('is_active', 1)
                ->addFieldToFilter('coupon_type', ['neq' => \Magento\SalesRule\Model\Rule::COUPON_TYPE_NO_COUPON])
                ->load();

            $this->_collection[] = array(
            	'label' => __('Disable'),
            	'value' => 0,
            );

            foreach ($coupons as $coupon) {
            	$this->_collection[] = array(
                    'label' => __($coupon['name']),
                    'value' => $coupon['rule_id'],
                );
            }

        }

        return $this->_collection;
    }

}