<?php


namespace Avologic\Checkoutspage\Model\Config\Source;

class SuggestionEmail extends Suggestion
{

    /**
     * Options getter
     *
     * @return Array
     */
    public function toOptionArray()
    {
        $array = parent::toOptionArray();
        foreach ($array as $key => $item) {
            if ($item['value'] == parent::SUGGESTION_TYPE_RECENTLY_VIEWED) {
                unset($array[$key]);
            }
        }

        return $array;
    }

    /**
     * Get options in "key-value" format
     *
     * @return Array
     */
    public function toArray()
    {
        $array = parent::toArray();
        unset($array[parent::SUGGESTION_TYPE_RECENTLY_VIEWED]);
        return $array;
    }
}
