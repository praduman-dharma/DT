<?php


namespace Avologic\Checkoutspage\Controller\Preview;

use Avologic\Checkoutspage\Helper\Data as DataHelper;

class Page extends \Avologic\Checkoutspage\Controller\Preview
{

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $order = $this->_getOrder();

        if (!$order || !$this->_canView()) {
            return $this->_redirectToCart();
        }

        $session = $this->getOnepage()->getCheckout();
        $session->setLastOrderId($order->getId())
            ->setLastSuccessQuoteId($order->getId())
            ->setLastQuoteId($order->getId())
            ->setLastRealOrderId($order->getIncrementId());

        $this->_customerSession->setData(DataHelper::PREVIEW_PARAM_NAME, 1);

        $this->_checkType();

        $this->_forward('success', 'onepage', 'checkout', ['preview' => true]);
    }

    /**
     * Check request typ
     * @return $this
     */
    protected function _checkType()
    {
        if ($this->getRequest()->getParam('type') == 'new' && !$this->helperData->moduleEnabled()) {
            $this->_changeModuleStatus(1);
        } elseif ($this->getRequest()->getParam('type') == 'old') {
            $this->_changeModuleStatus(0);
        }

        return $this;
    }
}
