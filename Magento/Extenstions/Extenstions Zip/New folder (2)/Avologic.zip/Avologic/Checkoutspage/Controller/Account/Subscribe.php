<?php



namespace Avologic\Checkoutspage\Controller\Account;

use Magento\Framework\App\Action\Context;

class Subscribe extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Avologic\Checkoutspage\Model\Subscribe
     */
    protected $_subscribeModel;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $_jsonHelper;

    /**
     * @var Avologic\Checkoutspage\Helper\Data
     */
    protected $_dataHelper;

    /**
     * @param Context                                   $context        
     * @param \Avologic\Checkoutspage\Model\Subscribe $subscribeModel 
     * @param \Magento\Framework\Json\Helper\Data       $jsonHelper     
     * @param \Avologic\Checkoutspage\Helper\Data     $helper         
     */
    public function __construct(
        Context $context,
        \Avologic\Checkoutspage\Model\Subscribe $subscribeModel,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Avologic\Checkoutspage\Helper\Data $helper
    ) {
        $this->_subscribeModel = $subscribeModel;
        $this->_dataHelper = $helper;
        $this->_jsonHelper = $jsonHelper;
        parent::__construct($context);
    }

    /**
     * @return $this 
     */
    public function execute()
    {
        if ($this->getRequest()->getParam('subscribe')) {
            $result = $this->_subscribeModel->subscribe();
            $errors = $this->_subscribeModel->getErrors();

            return $this->_jsonResponse($errors);
        }
    }

    /**
     * Compile JSON response
     *
     * @param string $error
     * @return Http
     */
    protected function _jsonResponse($error = '')
    {
        return $this->getResponse()->representJson(
            $this->_jsonHelper->jsonEncode($this->_dataHelper->getResponseData($error))
        );
    }

}