<?php


namespace Avologic\Checkoutspage\Block;

class Cms extends Page
{
    /**
     * @var Magento\Cms\Model\Template\FilterProvider
     */
    protected $_filterProvider;

    /**
     * @param \Avologic\Checkoutspage\Helper\Data            $helper
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Cms\Model\Template\FilterProvider                     $filterProvider
     * @param Array                                            $data
     */
    public function __construct(
        \Avologic\Checkoutspage\Helper\Data $helper,
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Cms\Model\Template\FilterProvider $filterProvider,
        array $data = []
    ) {
        parent::__construct($helper, $context, $data);
        $this->_filterProvider = $filterProvider;
    }

    /**
     * Is enabled
     * @param sting $location right|bottom
     * @return boolean
     */
    public function isEnabled($location)
    {
        if (!$this->_helper->moduleEnabled()) {
            return false;
        }

        return $this->_scopeConfig->getValue(
            \Avologic\Checkoutspage\Helper\Data::$configSectionId . '/cms_' . $location . '/enabled',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Get right cms content
     * @return string
     */
    public function getRightCmsContent()
    {
        return $this->_getContent(
            $this->_scopeConfig->getValue(
                \Avologic\Checkoutspage\Helper\Data::$configSectionId . '/cms_right/content',
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            )
        );
    }

    /**
     * Filter wysiwyg content
     * @param  string $content
     * @return string
     */
    protected function _getContent($content)
    {
        return $this->_filterProvider->getBlockFilter()->filter($content);
    }


    /**
     * Get bottom cms content
     * @return string
     */
    public function getBottomCmsContent()
    {
        return $this->_getContent(
            $this->_scopeConfig->getValue(
                \Avologic\Checkoutspage\Helper\Data::$configSectionId . '/cms_bottom/content',
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            )
        );
    }
}
