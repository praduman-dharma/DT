<?php


namespace Avologic\Checkoutspage\Block;

class Facebook extends Page
{

	/**
	 * is enabled
	 * @return boolean
	 */
	public function isEnabled()
	{
		return $this->getSettings('facebook/enabled');
	}

	/**
	 * get facebook url
	 * @return string url
	 */
	public function getFacebookUrl()
	{
		$url = $this->getSettings('facebook/url');
		$_url = parse_url($url);
        if (!isset($_url['scheme'])) {
            $url = 'http://' . $url;
        }
        return $url;
	}
}