<?php



namespace Avologic\Checkoutspage\Block;

use \Magento\Store\Model;

class Page extends \Magento\Framework\View\Element\Template
{

    /**
     * @var \Avologic\Checkoutspage\Helper\Data
     */
    protected $_helper;

    /**
     * @param \Avologic\Checkoutspage\Helper\Data            $helper  
     * @param \Magento\Framework\View\Element\Template\Context $context 
     * @param array                                            $data    
     */
    public function __construct(
        \Avologic\Checkoutspage\Helper\Data $helper,
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_helper = $helper;
    }

    /**
     * @return void
     */
    protected function _prepareLayout()
    {
        $this->getOrder();
    }

    /**
     * get order
     * @return \Magento\Sales\Model\Order
     */
    public function getOrder()
    {
        return $this->_helper->getOrder();
    }

    /**
     * get settings
     * @param  string $path 
     * @return string
     */
    public function getSettings($path)
    {
        return $this->_scopeConfig->getValue(
            \Avologic\Checkoutspage\Helper\Data::$configSectionId . '/' . $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * {@inheritdoc}
     */
    public function toHtml()
    {
        if (!$this->_helper->moduleEnabled()) {
            return '';
        }

        return parent::toHtml();
    }
}
