<?php


namespace Avologic\Checkoutspage\Block;

class Style extends Page
{
    /**
     * Get styles
     * @return Array
     */
    public function getStyle()
    {
        return $this->getSettings('design');
    }
}