<?php


namespace Avologic\Checkoutspage\Observer;

use Magento\Framework\Event\ObserverInterface;

class AddVariablesToOrderEmail implements ObserverInterface
{

    /**
     * @var \Avologic\Checkoutspage\Model\Email
     */
    protected $_emailModel;

    /**
     * @var \Avologic\Checkoutspage\Data\Helper
     */
    protected $_dataHelper;

    /**
     * @param \Avologic\Checkoutspage\Helper\Data $dataHelper 
     * @param \Avologic\Checkoutspage\Model\Email $emailModel 
     */
    public function __construct(
        \Avologic\Checkoutspage\Helper\Data $dataHelper,
        \Avologic\Checkoutspage\Model\Email $emailModel
    ) {
        $this->_emailModel = $emailModel;
        $this->_dataHelper = $dataHelper;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        if ($this->_dataHelper->getConfig(\Avologic\Checkoutspage\Helper\Data::$configSectionId .  '/email/enabled')
            && $this->_dataHelper->moduleEnabled()
        ) {
            $transport = $observer->getTransport();
            $order = $transport['order'];
            $this->_emailModel->addBetterOrderEmailVarsToOrder($order);
        }
    }

}