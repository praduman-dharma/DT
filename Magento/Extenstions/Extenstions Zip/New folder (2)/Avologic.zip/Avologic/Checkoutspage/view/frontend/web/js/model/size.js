
define(
    ['jquery'],
    function($) {
        "use strict";
        
        return {
            getScrollBarDimensions : function() {
                var elm = document.documentElement.offsetHeight ? document.documentElement : document.body,
                     curX = elm.clientWidth,
                     curY = elm.clientHeight,
                     hasScrollX = elm.scrollWidth > curX,
                     hasScrollY = elm.scrollHeight > curY,
                     prev = elm.style.overflow,
                     r = {
                        vertical: 0,
                        horizontal: 0
                     };

                if( !hasScrollY && !hasScrollX ) {
                    return r;
                }

                elm.style.overflow = "hidden";
                if( hasScrollY ) {
                    r.vertical = elm.clientWidth - curX;
                }

                if( hasScrollX ) {
                    r.horizontal = elm.clientHeight - curY;
                }
                elm.style.overflow = prev;

                return r;
            },

            windowSize : function() {
                var scroll = this.getScrollBarDimensions();
                return $( window ).width() + scroll.vertical;
            }
        }
    }
);
