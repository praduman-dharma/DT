<?php


namespace Avologic\Checkoutspage\Setup;

/* Uninstall Checkout Success Page */
class Uninstall extends \Avologic\Base\Setup\AbstractUninstall
{
    /**
     * Config section id
     * @var string
     */
    protected $_configSectionId = 'prcheckoutspage';

    /**
     * Tables fields
     * @var Array
     */
    protected $_tablesFields = ['sales_order' => ['next_order_promo_code']];

    /**
     * Pathes to files
     * @var Array
     */
    protected $_pathes = ['/app/code/Avologic/Checkoutspage'];

    /**
     * Attributes
     * @var Array
     */
    protected $_attributes = [\Magento\Catalog\Model\Product::ENTITY => ['pr_next_order_coupon']];
}
