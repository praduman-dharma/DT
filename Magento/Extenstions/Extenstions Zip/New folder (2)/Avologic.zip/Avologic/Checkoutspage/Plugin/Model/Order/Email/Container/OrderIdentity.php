<?php


namespace Avologic\Checkoutspage\Plugin\Model\Order\Email\Container;

use Magento\Sales\Model\Order\Email\Container\OrderIdentity as OriginOrderIdentity;

class OrderIdentity
{

    /**
     * @var \Avologic\Checkoutspage\Helper\Data
     */
    protected $_dataHelper;

    /**
     * @param \Avologic\Checkoutspage\Helper\Data $dataHelper [description]
     */
    public function __construct(
        \Avologic\Checkoutspage\Helper\Data $dataHelper
    ) {
        $this->_dataHelper = $dataHelper;
    }

    /**
     * After get template id
     * @param  OriginOrderIdentity $subject 
     * @param string $result 
     * @return string
     */
    public function afterGetTemplateId(OriginOrderIdentity $subject, $result)
    {
        if ($this->_isEmailEnabled()) {
            return $this->_dataHelper->getConfig($this->_getPath() . '/template');
        }

        return $result;
    }

    /**
     * After get guest template id
     * @param  OriginOrderIdentity $subject
     * @param string $result 
     * @return string
     */
    public function afterGetGuestTemplateId(OriginOrderIdentity $subject, $result)
    {
        if ($this->_isEmailEnabled()) {
            return $this->_dataHelper->getConfig($this->_getPath() . '/template');
        }

        return $result;
    }

    /**
     * Is "use better email" enabled
     * @return boolean 
     */
    protected function _isEmailEnabled()
    {
        return $this->_dataHelper->getConfig($this->_getPath() . '/enabled');
    }

    /**
     * Get path to section
     * @return string 
     */
    protected function _getPath()
    {
        return $this->_dataHelper->getConfigSectionId() .   '/email';
    }
}
