<?php


namespace Avologic\Checkoutspage\Plugin\Framework\App;

use Magento\Framework\App\Config\ScopeConfigInterface;

class ConfigPlugin
{
    const ENABLE_PATH = 'prcheckoutspage/general/enabled';
    const ENABLE_PATH_ON = 'prcheckoutspage/general/enabled_on';
    const ENABLE_PATH_OFF  ='prcheckoutspage/general/enabled_off';

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $request;

    public function __construct(
        \Magento\Framework\App\RequestInterface $request
    ) {
        $this->request = $request;
    }

    public function beforeGetValue(
        \Magento\Framework\App\Config $subject,
        $path = null,
        $scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
        $scopeCode = null
    ) {

        if ($path == self::ENABLE_PATH) {
            if ($this->request->getParam('type') == 'new') {
                $path = self::ENABLE_PATH_ON;
            } else if ($this->request->getParam('type') == 'old') {
                $path = self::ENABLE_PATH_OFF;
            }
        }

        return [$path, $scope, $scopeCode];
    }
}
