define([
    './abstract'
], function (Abstract) {
    'use strict';

    return Abstract.extend({
    });
});