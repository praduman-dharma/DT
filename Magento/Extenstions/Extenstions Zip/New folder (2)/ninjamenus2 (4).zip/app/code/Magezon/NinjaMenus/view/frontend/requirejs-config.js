var config = {
    map: {
        '*': {
            'ninjamenus': 'Magezon_NinjaMenus/js/ninjamenus',
            'ninjamenustop': 'Magezon_NinjaMenus/js/ninjamenustop',
            'Magento_Catalog/js/product/breadcrumbs': 'Magezon_NinjaMenus/js/product/breadcrumbs'
        }
    }
};