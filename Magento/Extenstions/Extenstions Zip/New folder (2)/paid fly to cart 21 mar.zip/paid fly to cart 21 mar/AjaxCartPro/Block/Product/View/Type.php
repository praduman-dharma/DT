<?php
namespace Magetop\AjaxCartPro\Block\Product\View;
class Type extends \Magento\Catalog\Block\Product\View\AbstractView
{
	
}