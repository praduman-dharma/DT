<?php

namespace MageBig\WidgetPlus\Block;

class RecentlyViewed extends \Magento\Catalog\Block\Widget\RecentlyViewed
{

}