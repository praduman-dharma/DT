var config = {
    map: {
        "*": {
            "mage/adminhtml/form": "MageBig_WidgetPlus/js/form"
        }
    }
};
